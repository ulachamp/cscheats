$ErrorActionPreference = 'Stop'
$target = Join-Path $PSScriptRoot 'cstrike\dlls\mp.dll'
$backup = "$target.clienttrace.bak"
$originalSha = '5596780734fa40dd709537b26b9a0bf4cf970c150fcc03108ed5432b65e3c331'
$patchedSha = 'fcc4051f04b9be3dd4b4e3177e9b211699dec88e35d4da03939b8008b35d5bcc'
try {
    if (-not (Test-Path -LiteralPath $backup -PathType Leaf)) {
        throw 'Zaxira mp.dll.clienttrace.bak topilmadi.'
    }
    $backupSha = (Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($backupSha -ne $originalSha) { throw 'Zaxira fayl tekshiruvdan o`tmadi. Tiklash bekor qilindi.' }
    if (Test-Path -LiteralPath $target -PathType Leaf) {
        $currentSha = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
        if (($currentSha -ne $originalSha) -and ($currentSha -ne $patchedSha)) {
            throw 'mp.dll keyin o`zgartirilgan. Mavjud faylga tegilmadi.'
        }
    }
    [System.IO.File]::Copy($backup, $target, $true)
    Write-Host 'TIKLANDI: original mp.dll qaytarildi. proo.cfg o`zgarmadi.' -ForegroundColor Green
} catch {
    Write-Host "XATO: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
