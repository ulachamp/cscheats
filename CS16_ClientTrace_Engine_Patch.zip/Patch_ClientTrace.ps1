$ErrorActionPreference = 'Stop'
$target = Join-Path $PSScriptRoot 'cstrike\dlls\mp.dll'
$backup = "$target.clienttrace.bak"
$originalSha = '5596780734fa40dd709537b26b9a0bf4cf970c150fcc03108ed5432b65e3c331'
$patchedSha = 'fcc4051f04b9be3dd4b4e3177e9b211699dec88e35d4da03939b8008b35d5bcc'
$offset = 0x5D452

try {
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) {
        throw 'mp.dll topilmadi. Patch fayllarini CS 1.6 bosh papkasiga (cs.exe yoniga) qo`ying.'
    }
    $currentSha = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($currentSha -eq $patchedSha) {
        Write-Host 'ClientTrace patch allaqachon o`rnatilgan.' -ForegroundColor Yellow
        exit 0
    }
    if ($currentSha -ne $originalSha) {
        throw "mp.dll versiyasi boshqa. Xavfsizlik uchun fayl o`zgartirilmadi. SHA256: $currentSha"
    }
    $bytes = [System.IO.File]::ReadAllBytes($target)
    if (($bytes.Length -le ($offset + 1)) -or ($bytes[$offset] -ne 0x7B) -or ($bytes[$offset + 1] -ne 0x14)) {
        throw 'Kerakli kod belgisi mos kelmadi. Patch qo`llanmadi.'
    }
    if (-not (Test-Path -LiteralPath $backup)) {
        [System.IO.File]::Copy($target, $backup, $false)
    } elseif ((Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash.ToLowerInvariant() -ne $originalSha) {
        throw 'Zaxira mp.dll mavjud, ammo tekshiruvdan o`tmadi. Patch qo`llanmadi.'
    }
    # JMP o`tkazish: 7B 14 (JNP +20) -> EB 14 (JMP +20).
    # CS 1.6 GameDLL ichidagi sv_clienttrace=1 qayta yozish yo`lini o`tkazib yuboradi.
    $bytes[$offset] = 0xEB
    [System.IO.File]::WriteAllBytes($target, $bytes)
    $resultSha = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($resultSha -ne $patchedSha) { throw 'Yangi fayl hash tekshiruvidan o`tmadi. Zaxiradan tiklang.' }
    Write-Host 'TAYYOR: mp.dll patch qilindi. proo.cfg o`zgarmadi.' -ForegroundColor Green
    Write-Host 'Zaxira: cstrike\dlls\mp.dll.clienttrace.bak'
    Write-Host 'Endi CS 1.6 ni ochib botlar bilan tekshiring.'
} catch {
    Write-Host "XATO: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
