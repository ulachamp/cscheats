CS 1.6 — sv_clienttrace 1 ga qaytishini to'xtatish tajriba patchi

Faqat siz yuborgan CS 1.6.zip ichidagi mp.dll versiyasi uchun.
proo.cfg, botlar, til va o'yin konfiguratsiyalariga tegmaydi.
Windows o'yinda tekshirilmagan. Har ehtimolga qarshi zaxira nusxa yaratiladi.

O'RNATISH:
1) CS 1.6 ni yoping.
2) ZIP ichidagi 4 ta faylni o'yin asosiy papkasiga, cs.exe yoniga qo'ying.
3) 1_PATCH.bat ni ikki marta bosing.
4) Yashil TAYYOR xabarini kuting.
5) CS 1.6 ni oching, botlar bilan lokal o'yin boshlang.
6) Konsolga: sv_clienttrace 9999
7) So'ng: sv_clienttrace

MUHIM:
Bu o'zgarish sv_clienttrace ning majburan 1 ga qaytarilishini to'xtatishga mo'ljallangan,
lekin avtomatik nishonga olishni YOKI bullet hitboxlarini kattalashtirishni ta'minlamaydi.
O'yin yopilib qolsa, 2_RESTORE.bat faylini ishlating.

TIKLASH:
CS 1.6 ni yoping va 2_RESTORE.bat ni ishga tushiring.
Zaxira fayl cstrike\dlls\mp.dll.clienttrace.bak da saqlanadi.
Agar AMX Mod X hali ham xato bersa, bu patch uni tuzatmasligi mumkin.

Patch faqat tekshirilgan 1 baytni o'zgartiradi: 0x5D452 7B -> EB.
Boshqa mp.dll versiyasiga bu patch avtomatik ravishda qo'llanmaydi.
