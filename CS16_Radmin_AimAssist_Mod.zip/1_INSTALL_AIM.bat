@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "cs.exe" (
  echo XATO: ZIP ichidagi fayllarni CS 1.6 ning cs.exe yoniga chiqaring.
  pause
  exit /b 1
)
if not exist "cstrike\addons\amxmodx\configs\plugins.ini" (
  echo XATO: cstrike\addons\amxmodx\configs\plugins.ini topilmadi.
  echo AMX Mod X fayllari mavjud emas.
  pause
  exit /b 1
)
if exist "cstrike\addons\amxmodx\plugins\aim_radmin.amxx" (
  echo XATO: aim_radmin.amxx oldin mavjud. Faylni almashtirmadim.
  pause
  exit /b 1
)
echo Aim plugin tuzilmoqda...
"%~dp0tools\amxxpc.exe" "%~dp0aim_radmin.sma" "-i%~dp0tools\include" "-o%~dp0aim_radmin.amxx"
if errorlevel 1 goto compileerror
if not exist "aim_radmin.amxx" goto compileerror
copy /b "aim_radmin.amxx" "cstrike\addons\amxmodx\plugins\aim_radmin.amxx" >nul
if errorlevel 1 goto compileerror
set "CFG=cstrike\addons\amxmodx\configs\plugins.ini"
if not exist "%CFG%.before_aim.bak" copy /b "%CFG%" "%CFG%.before_aim.bak" >nul
findstr /r /i /c:"^[ ]*aim_radmin\.amxx" "%CFG%" >nul
if errorlevel 1 echo aim_radmin.amxx>>"%CFG%"
echo.
echo TAYYOR: aim_radmin.amxx plugin fayli o'rnatildi.
echo proo.cfg, mp.dll va botlar O'ZGARMADI.
echo MUHIM: AMX Mod X o'yinda yoqilgan bo'lishi shart.
echo Oyinda chatga /aim yozib yoqish/o'chirish mumkin.
echo Agar avval AMX Mod X o'yinni yopgan bo'lsa, uni majburan yoqmang.
pause
exit /b 0
:compileerror
echo.
echo XATO: AIM plugin tuzilmadi. Avval AMX Mod X xatosini tuzatish kerak bo'lishi mumkin.
pause
exit /b 1
