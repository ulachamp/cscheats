CS 1.6 — RADMIN AIM ASSIST (shaxsiy server uchun, sinov mod)

NIMA QILADI:
- /aim yozgan O'YINCHINING kursorini ko'rinib turgan qarshi jamoa o'yinchisiga yaqinlashtiradi.
- Faqat hujum tugmasi bosilganda, taxminan 7 daraja oralig'ida ishlashga mo'ljallangan.
- Maqsad devor ortida bo'lsa ishlamasligi kerak.
- Radmin VPN'dagi o'zingiz ochgan serverda sinash mumkin.
- Bu sv_clienttrace=9999 emas, mustaqil AMX Mod X plaginidir.
- Plugin Windows ichida o'yin bilan SINOVDAN O'TKAZILMAGAN, kafolat yo'q.

O'RNATISH:
1) CS 1.6 ni to'liq yoping.
2) ZIP ichidagi 1_INSTALL_AIM.bat, 2_REMOVE_AIM.bat, aim_radmin.sma va tools papkasini
   CS 1.6 ichidagi cs.exe bilan BIR JOYGA nusxalang.
3) 1_INSTALL_AIM.bat ni ishga tushiring.
4) "TAYYOR" yozuvini tekshiring.
5) CS 1.6 ni oching, botlar bilan xususiy xaritani oching.
6) Konsol: meta list, so'ng amx_plugins.
7) O'yinda chatga /aim deb yozib, aim-assistni yoqing/o'chiring.

RADMIN VPN:
- Serverni siz ochishingiz kerak. Serverda AMX Mod X ishlayotgan bo'lsin.
- O'yinchilar chatga /aim deb yozib o'zlarida yoqishi yoki o'chirishi mumkin.
- Do'stlarning o'yin fayllarini o'zgartirish kerak emas.

SOZLASH (server konsoli):
radmin_aim_fov 7.0
Qiymat 3.0: kichikroq, 10.0: kattaroq burchak.

JIDDIY OG'OHLANTIRISH:
- Sizning oldingi CS 1.6 tuzatishingiz Metamod/AMX Mod X ni
  o'yin yopilib qolmasligi uchun o'chirgan bo'lishi mumkin.
- 'Unknown command: amx_plugins' chiqsa plugin ishlamaydi.
- Agar AMX'ni yoqqanda o'yin yopilsa, uni hozircha yoqmang.
  Crash tuzatilmaguncha bu AMX mod ishlamaydi.
- Bu dastur game DLL yoki engine fayllarini tahrirlamaydi.
- proo.cfg, mp.dll, boshqa CFG, o'yin tili, botlar o'zgarmaydi.
- tools ichidagi kompilyator Siz yuborgan CS 1.6 ZIP'idan olindi.

O'CHIRISH:
2_REMOVE_AIM.bat ni ishga tushiring.
