@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
if not exist "cs.exe" (
 echo CS 1.6 cs.exe topilmadi.
 pause
 exit /b 1
)
set "CFG=cstrike\addons\amxmodx\configs\plugins.ini"
if not exist "%CFG%" (
 echo plugins.ini topilmadi.
 pause
 exit /b 1
)
set "TEMPFILE=%TEMP%\aim_plugins_%RANDOM%.tmp"
findstr /v /r /i /c:"^[ ]*aim_radmin\.amxx" "%CFG%" > "%TEMPFILE%"
if errorlevel 2 (
 echo XATO: plugins.ini o'qilmadi.
 pause
 exit /b 1
)
copy /b "%TEMPFILE%" "%CFG%" >nul
del /q "%TEMPFILE%"
if exist "cstrike\addons\amxmodx\plugins\aim_radmin.amxx" del /q "cstrike\addons\amxmodx\plugins\aim_radmin.amxx"
echo AIM plugin o'chirildi. proo.cfg o'zgarmadi.
pause
