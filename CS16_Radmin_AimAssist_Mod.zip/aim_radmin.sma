/*
 * Counter-Strike 1.6 private-server aim-assist training plugin.
 * Opt-in per player: say /aim. Requires AMX Mod X and Fakemeta.
 * No binary DLL changes. Does not touch proo.cfg.
 */
#include <amxmodx>
#include <fakemeta>
#include <float>
#include <hlsdk_const>

new bool:g_enabled[33];
new g_pFov;

public plugin_init()
{
    register_plugin("Radmin Aim Assist", "1.0", "Private Server");
    register_clcmd("say /aim", "cmd_toggle");
    register_clcmd("say_team /aim", "cmd_toggle");
    g_pFov = register_cvar("radmin_aim_fov", "7.0");
    register_forward(FM_PlayerPreThink, "on_prethink");
}

public client_disconnect(id)
{
    g_enabled[id] = false;
}

public cmd_toggle(id)
{
    g_enabled[id] = !g_enabled[id];
    if (g_enabled[id])
        client_print(id, print_chat, "[AIM] ON (faqat shu serverda)");
    else
        client_print(id, print_chat, "[AIM] OFF (faqat shu serverda)");
    return PLUGIN_HANDLED;
}

public on_prethink(id)
{
    if (!g_enabled[id] || !is_user_alive(id) || is_user_bot(id))
        return FMRES_IGNORED;

    if (!(pev(id, pev_button) & IN_ATTACK))
        return FMRES_IGNORED;

    new Float:eye[3], Float:ofs[3], Float:view[3];
    pev(id, pev_origin, eye);
    pev(id, pev_view_ofs, ofs);
    eye[0] += ofs[0];
    eye[1] += ofs[1];
    eye[2] += ofs[2];
    pev(id, pev_v_angle, view);

    new players[32], count;
    get_players(players, count, "a");
    new team = get_user_team(id);
    new Float:bestScore = get_pcvar_float(g_pFov);
    new Float:bestAngles[3];
    new bool:found = false;
    new trace = create_tr2();

    for (new k = 0; k < count; k++)
    {
        new targetId = players[k];
        if (targetId == id || get_user_team(targetId) == team)
            continue;

        new Float:target[3], Float:targetOfs[3];
        pev(targetId, pev_origin, target);
        pev(targetId, pev_view_ofs, targetOfs);
        target[0] += targetOfs[0];
        target[1] += targetOfs[1];
        target[2] += targetOfs[2];

        engfunc(EngFunc_TraceLine, eye, target, DONT_IGNORE_MONSTERS, id, trace);
        if (get_tr2(trace, TR_pHit) != targetId)
            continue;

        new Float:dx = target[0] - eye[0];
        new Float:dy = target[1] - eye[1];
        new Float:dz = target[2] - eye[2];
        new Float:flat = floatsqroot(dx * dx + dy * dy);
        new Float:pitch = -floatatan2(dz, flat, degrees);
        new Float:yaw = floatatan2(dy, dx, degrees);
        new Float:dPitch = angle_difference(pitch, view[0]);
        new Float:dYaw = angle_difference(yaw, view[1]);
        new Float:score = floatsqroot(dPitch*dPitch + dYaw*dYaw);

        if (score < bestScore)
        {
            bestScore = score;
            bestAngles[0] = pitch;
            bestAngles[1] = yaw;
            bestAngles[2] = 0.0;
            found = true;
        }
    }
    free_tr2(trace);

    if (found)
    {
        // Engine's server-side view-angle mechanism. Clients see a brief snap.
        set_pev(id, pev_v_angle, bestAngles);
        set_pev(id, pev_angles, bestAngles);
        set_pev(id, pev_fixangle, 1);
    }
    return FMRES_IGNORED;
}

stock Float:angle_difference(Float:a, Float:b)
{
    new Float:delta = a - b;
    while (delta > 180.0) delta -= 360.0;
    while (delta < -180.0) delta += 360.0;
    return floatabs(delta);
}
